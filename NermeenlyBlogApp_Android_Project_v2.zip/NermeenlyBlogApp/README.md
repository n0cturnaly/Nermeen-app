# Nermeenly Android App

A minimal Android WebView app for:
https://nermly.blogspot.com/

## Included
- The supplied red "N" image is used as the launcher icon.
- Transparent status bar.
- Black status-bar icons/text.
- Red navigation bar matching the icon.
- Portrait orientation.
- JavaScript, DOM storage and cookies enabled for the blog.
- Android Back navigates inside the blog before exiting.

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated APK will be under:
app/build/outputs/apk/debug/

For a release APK, use:
Build > Generate Signed Bundle / APK > APK
